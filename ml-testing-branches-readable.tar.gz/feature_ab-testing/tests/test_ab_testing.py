import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from mlpipe.ab_testing import split_traffic, compare_models, proportions_ztest

pytest.importorskip("scipy")


def test_split_traffic_roughly_balanced():
    arms = split_traffic(10000, frac_b=0.5, seed=0)
    assert 0.45 < arms.mean() < 0.55


def test_no_difference_not_significant():
    rng = np.random.default_rng(0)
    a = rng.random(2000) < 0.8
    b = rng.random(2000) < 0.8
    res = compare_models(a, b)
    assert not res.significant
    assert res.winner == "tie"


def test_clear_difference_detected():
    rng = np.random.default_rng(1)
    a = rng.random(3000) < 0.70
    b = rng.random(3000) < 0.85
    res = compare_models(a, b)
    assert res.significant
    assert res.winner == "B"
    assert res.lift > 0


def test_ztest_symmetry():
    z1, p1 = proportions_ztest(80, 100, 90, 100)
    z2, p2 = proportions_ztest(90, 100, 80, 100)
    assert np.isclose(p1, p2)
    assert np.isclose(z1, -z2)
