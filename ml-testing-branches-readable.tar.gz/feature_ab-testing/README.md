# ML Testing and Validation

Shared `main` scaffold. Each testing concern lives on its own feature branch off `main`:

| Branch | Focus | Key libs |
|---|---|---|
| `feature/unit-tests` | Pipeline unit test suite | pytest |
| `feature/input-validation` | Input data validation | Great Expectations, Pydantic |
| `feature/drift-detection` | Data & model drift in prod | Evidently AI |
| `feature/ab-testing` | A/B testing of models | scipy, statsmodels |
| `feature/fairness-testing` | Fairness & model lifespan | Fairlearn, AIF360 |
| `feature/cv-tuning` | Cross-val & hyperparam tuning | Optuna, sklearn |

Model: a small PyTorch MLP. Data: synthetic, generated on the fly (no downloads).
