"""Small PyTorch MLP + sklearn-style wrapper used across all branches."""
from __future__ import annotations
import numpy as np

try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
except Exception:  # torch optional at import time so non-torch tests still run
    _HAS_TORCH = False


if _HAS_TORCH:
    class MLP(nn.Module):
        def __init__(self, in_dim: int = 4, hidden: int = 16):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU(),
                nn.Linear(hidden, 2),
            )

        def forward(self, x):
            return self.net(x)


class TorchClassifier:
    """Minimal sklearn-compatible estimator (fit/predict/predict_proba).

    Compatible enough for GridSearchCV, Optuna, Fairlearn, and Evidently.
    """

    def __init__(self, hidden: int = 16, lr: float = 1e-2, epochs: int = 40, seed: int = 0):
        self.hidden = hidden
        self.lr = lr
        self.epochs = epochs
        self.seed = seed

    # sklearn clone() needs these
    def get_params(self, deep: bool = True):
        return {"hidden": self.hidden, "lr": self.lr, "epochs": self.epochs, "seed": self.seed}

    def set_params(self, **p):
        for k, v in p.items():
            setattr(self, k, v)
        return self

    def fit(self, X, y):
        if not _HAS_TORCH:
            raise RuntimeError("PyTorch not installed")
        torch.manual_seed(self.seed)
        self.classes_ = np.unique(y)
        Xt = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        yt = torch.as_tensor(np.asarray(y), dtype=torch.long)
        self.model_ = MLP(in_dim=Xt.shape[1], hidden=self.hidden)
        opt = torch.optim.Adam(self.model_.parameters(), lr=self.lr)
        loss_fn = nn.CrossEntropyLoss()
        self.model_.train()
        for _ in range(self.epochs):
            opt.zero_grad()
            out = self.model_(Xt)
            loss = loss_fn(out, yt)
            loss.backward()
            opt.step()
        return self

    def predict_proba(self, X):
        Xt = torch.as_tensor(np.asarray(X), dtype=torch.float32)
        self.model_.eval()
        with torch.no_grad():
            logits = self.model_(Xt)
            return torch.softmax(logits, dim=1).numpy()

    def predict(self, X):
        return self.predict_proba(X).argmax(axis=1)

    def score(self, X, y):
        return float((self.predict(X) == np.asarray(y)).mean())
