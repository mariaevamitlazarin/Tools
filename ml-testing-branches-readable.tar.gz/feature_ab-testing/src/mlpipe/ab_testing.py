"""A/B testing framework for comparing two models in production."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import stats


@dataclass
class ABResult:
    metric_a: float
    metric_b: float
    lift: float            # (b - a) / a
    p_value: float
    significant: bool
    winner: str            # "A", "B", or "tie"


def split_traffic(n: int, frac_b: float = 0.5, seed: int = 0) -> np.ndarray:
    """Deterministic per-request assignment to arm A (0) or B (1)."""
    rng = np.random.default_rng(seed)
    return (rng.random(n) < frac_b).astype(int)


def proportions_ztest(success_a, n_a, success_b, n_b):
    """Two-proportion z-test (e.g. comparing accuracy / click rate)."""
    p_a, p_b = success_a / n_a, success_b / n_b
    p_pool = (success_a + success_b) / (n_a + n_b)
    se = np.sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
    if se == 0:
        return 0.0, 1.0
    z = (p_b - p_a) / se
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return float(z), float(p)


def compare_models(correct_a, correct_b, alpha: float = 0.05) -> ABResult:
    """correct_a / correct_b: boolean arrays of per-sample correctness per arm."""
    correct_a = np.asarray(correct_a).astype(int)
    correct_b = np.asarray(correct_b).astype(int)
    acc_a, acc_b = correct_a.mean(), correct_b.mean()
    _, p = proportions_ztest(correct_a.sum(), len(correct_a),
                             correct_b.sum(), len(correct_b))
    sig = p < alpha
    winner = "tie"
    if sig:
        winner = "B" if acc_b > acc_a else "A"
    lift = (acc_b - acc_a) / acc_a if acc_a else 0.0
    return ABResult(float(acc_a), float(acc_b), float(lift), p, sig, winner)
