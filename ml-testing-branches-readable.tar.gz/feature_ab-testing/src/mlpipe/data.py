"""Synthetic tabular data generation — deterministic, no downloads."""
from __future__ import annotations
import numpy as np


FEATURE_NAMES = ["age", "income", "score", "tenure"]
SENSITIVE_NAME = "group"  # binary sensitive attribute for fairness tests


def make_dataset(n: int = 2000, seed: int = 0, drift: float = 0.0):
    """Return (X, y, sensitive).

    X: (n, 4) float32 features
    y: (n,) int64 binary labels
    sensitive: (n,) int64 in {0,1}
    `drift` shifts the feature means to simulate production drift.
    """
    rng = np.random.default_rng(seed)
    sensitive = rng.integers(0, 2, size=n)
    base = rng.normal(0.0, 1.0, size=(n, len(FEATURE_NAMES))).astype(np.float32)
    base += drift  # mean shift simulates covariate drift
    # group introduces a mild, learnable signal (lets fairness gaps appear)
    logits = base @ np.array([0.8, -0.5, 1.1, 0.3], dtype=np.float32)
    logits += 0.6 * sensitive
    p = 1.0 / (1.0 + np.exp(-logits))
    y = (rng.random(n) < p).astype(np.int64)
    return base, y, sensitive.astype(np.int64)
