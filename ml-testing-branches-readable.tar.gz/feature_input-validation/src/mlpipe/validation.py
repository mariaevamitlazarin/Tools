"""Input data validation with Pydantic (row-level) + Great Expectations (batch)."""
from __future__ import annotations
import numpy as np
from pydantic import BaseModel, Field, field_validator
from mlpipe.data import FEATURE_NAMES


class FeatureRow(BaseModel):
    """Row-level schema/contract for a single inference request."""
    age: float = Field(..., ge=-5, le=5)
    income: float = Field(..., ge=-5, le=5)
    score: float = Field(..., ge=-5, le=5)
    tenure: float = Field(..., ge=-5, le=5)

    @field_validator("*")
    @classmethod
    def not_nan(cls, v):
        if v != v:  # NaN check
            raise ValueError("NaN not allowed")
        return v


def validate_rows(X: np.ndarray) -> list[FeatureRow]:
    """Validate every row, raising pydantic.ValidationError on the first bad row."""
    rows = []
    for r in np.asarray(X):
        rows.append(FeatureRow(**dict(zip(FEATURE_NAMES, map(float, r)))))
    return rows


def build_expectation_suite(X: np.ndarray):
    """Build a Great Expectations suite over a pandas batch.

    Returns the GE validation result object. GE imported lazily so the rest of
    the module works without it installed.
    """
    import pandas as pd
    import great_expectations as gx

    df = pd.DataFrame(np.asarray(X), columns=FEATURE_NAMES)
    context = gx.get_context(mode="ephemeral")
    batch = context.data_sources.add_pandas("syn").add_dataframe_asset(
        "features"
    ).add_batch_definition_whole_dataframe("batch").get_batch(
        batch_parameters={"dataframe": df}
    )
    suite = gx.ExpectationSuite(name="feature_suite")
    for col in FEATURE_NAMES:
        suite.add_expectation(
            gx.expectations.ExpectColumnValuesToNotBeNull(column=col)
        )
        suite.add_expectation(
            gx.expectations.ExpectColumnValuesToBeBetween(
                column=col, min_value=-5, max_value=5
            )
        )
    return batch.validate(suite)
