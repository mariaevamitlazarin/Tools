import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from pydantic import ValidationError
from mlpipe.data import make_dataset
from mlpipe.validation import FeatureRow, validate_rows


def test_valid_rows_pass():
    X, _, _ = make_dataset(n=50, seed=3)
    X = np.clip(X, -5, 5)
    rows = validate_rows(X)
    assert len(rows) == 50
    assert isinstance(rows[0], FeatureRow)


def test_out_of_range_rejected():
    with pytest.raises(ValidationError):
        FeatureRow(age=99, income=0, score=0, tenure=0)


def test_nan_rejected():
    with pytest.raises(ValidationError):
        FeatureRow(age=float("nan"), income=0, score=0, tenure=0)


@pytest.mark.ge
def test_great_expectations_suite():
    gx = pytest.importorskip("great_expectations")
    from mlpipe.validation import build_expectation_suite
    X, _, _ = make_dataset(n=200, seed=5)
    X = np.clip(X, -5, 5)
    result = build_expectation_suite(X)
    assert result.success
