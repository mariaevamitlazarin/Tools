import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from mlpipe.data import make_dataset

torch = pytest.importorskip("torch")
from mlpipe.tuning import cv_scores, grid_search


@pytest.fixture(scope="module")
def data():
    return make_dataset(n=400, seed=0)


def test_cv_returns_one_score_per_fold(data):
    X, y, _ = data
    scores = cv_scores(X, y, cv=5, epochs=20)
    assert scores.shape == (5,)
    assert scores.mean() > 0.5


def test_grid_search_finds_best(data):
    X, y, _ = data
    gs = grid_search(X, y, cv=3)
    assert hasattr(gs, "best_params_")
    assert 0.0 <= gs.best_score_ <= 1.0
    assert set(gs.best_params_) == {"hidden", "lr", "epochs"}


@pytest.mark.optuna
def test_optuna_improves(data):
    pytest.importorskip("optuna")
    from mlpipe.tuning import optuna_search
    X, y, _ = data
    study = optuna_search(X, y, n_trials=8, cv=3)
    assert study.best_value > 0.5
    assert "lr" in study.best_params
