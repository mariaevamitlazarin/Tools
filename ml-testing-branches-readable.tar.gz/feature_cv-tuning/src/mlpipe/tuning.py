"""Cross-validation & hyperparameter tuning (Optuna, GridSearchCV)."""
from __future__ import annotations
import numpy as np
from sklearn.model_selection import cross_val_score, GridSearchCV, StratifiedKFold
from mlpipe.model import TorchClassifier


def cv_scores(X, y, cv: int = 5, **clf_kwargs) -> np.ndarray:
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=0)
    return cross_val_score(TorchClassifier(**clf_kwargs), X, y, cv=skf, scoring="accuracy")


def grid_search(X, y, cv: int = 3):
    grid = {"hidden": [8, 16], "lr": [1e-2, 5e-3], "epochs": [30]}
    gs = GridSearchCV(
        TorchClassifier(), grid, cv=cv, scoring="accuracy", n_jobs=1, refit=True,
    )
    gs.fit(X, y)
    return gs


def optuna_search(X, y, n_trials: int = 15, cv: int = 3):
    """Optuna study over the same search space (imported lazily)."""
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    def objective(trial):
        params = {
            "hidden": trial.suggest_categorical("hidden", [8, 16, 32]),
            "lr": trial.suggest_float("lr", 1e-3, 5e-2, log=True),
            "epochs": trial.suggest_int("epochs", 20, 60, step=10),
        }
        return float(cv_scores(X, y, cv=cv, **params).mean())

    study = optuna.create_study(direction="maximize",
                                sampler=optuna.samplers.TPESampler(seed=0))
    study.optimize(objective, n_trials=n_trials)
    return study
