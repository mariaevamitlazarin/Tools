import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from mlpipe.fairness import (
    demographic_parity_difference, equal_opportunity_difference, lifespan_check,
)


def test_perfect_parity():
    y_pred = np.array([1, 0, 1, 0, 1, 0])
    sens = np.array([0, 0, 0, 1, 1, 1])
    # each group: one third positive? -> make equal
    y_pred = np.array([1, 0, 0, 1, 0, 0])
    assert demographic_parity_difference(y_pred, sens) == 0.0


def test_disparity_detected():
    sens = np.array([0]*100 + [1]*100)
    y_pred = np.array([1]*90 + [0]*10 + [0]*90 + [1]*10)
    dpd = demographic_parity_difference(y_pred, sens)
    assert dpd > 0.5


def test_equal_opportunity():
    y_true = np.array([1, 1, 1, 1])
    y_pred = np.array([1, 1, 0, 0])
    sens = np.array([0, 0, 1, 1])
    assert equal_opportunity_difference(y_true, y_pred, sens) == 1.0


def test_lifespan_flags_floor_breach():
    out = lifespan_check([0.90, 0.88, 0.70], min_metric=0.80, max_drop=0.5)
    assert out["below_floor"] and out["retrain_recommended"]


def test_lifespan_flags_degradation():
    out = lifespan_check([0.95, 0.94, 0.60], min_metric=0.50, max_drop=0.2)
    assert out["degraded"] and out["retrain_recommended"]


def test_lifespan_healthy():
    out = lifespan_check([0.90, 0.91, 0.905], min_metric=0.80, max_drop=0.2)
    assert not out["retrain_recommended"]


@pytest.mark.fairlearn
def test_fairlearn_matches_manual():
    pytest.importorskip("fairlearn")
    from mlpipe.fairness import fairlearn_metrics
    sens = np.array([0]*100 + [1]*100)
    y_true = np.random.default_rng(0).integers(0, 2, 200)
    y_pred = np.array([1]*90 + [0]*10 + [0]*90 + [1]*10)
    m = fairlearn_metrics(y_true, y_pred, sens)
    assert np.isclose(m["demographic_parity_difference"],
                      demographic_parity_difference(y_pred, sens), atol=1e-6)
