"""Fairness & model-lifespan testing (Fairlearn, AIF360).

Includes pure-numpy fairness metrics as a fallback so tests have signal even
without the heavy libraries installed.
"""
from __future__ import annotations
import numpy as np


def selection_rate(y_pred, sensitive, group) -> float:
    mask = np.asarray(sensitive) == group
    return float(np.asarray(y_pred)[mask].mean()) if mask.any() else 0.0


def demographic_parity_difference(y_pred, sensitive) -> float:
    """|P(ŷ=1|A=0) - P(ŷ=1|A=1)|. 0 == parity."""
    return abs(selection_rate(y_pred, sensitive, 0) -
               selection_rate(y_pred, sensitive, 1))


def equal_opportunity_difference(y_true, y_pred, sensitive) -> float:
    """|TPR_group0 - TPR_group1|."""
    y_true, y_pred, s = map(np.asarray, (y_true, y_pred, sensitive))
    def tpr(g):
        m = (s == g) & (y_true == 1)
        return float(y_pred[m].mean()) if m.any() else 0.0
    return abs(tpr(0) - tpr(1))


def fairlearn_metrics(y_true, y_pred, sensitive) -> dict:
    """Compute the same metrics via Fairlearn (imported lazily)."""
    from fairlearn.metrics import (
        demographic_parity_difference as dpd,
        equalized_odds_difference as eod,
    )
    return {
        "demographic_parity_difference": float(
            dpd(y_true, y_pred, sensitive_features=sensitive)),
        "equalized_odds_difference": float(
            eod(y_true, y_pred, sensitive_features=sensitive)),
    }


def lifespan_check(metric_history: list[float], min_metric: float, max_drop: float):
    """Model-lifespan guardrail: flag retraining when a tracked production
    metric falls below `min_metric` or drops more than `max_drop` from its peak.
    """
    history = np.asarray(metric_history, dtype=float)
    current = float(history[-1])
    peak = float(history.max())
    below_floor = current < min_metric
    big_drop = (peak - current) > max_drop
    return {
        "current": current,
        "peak": peak,
        "below_floor": below_floor,
        "degraded": big_drop,
        "retrain_recommended": below_floor or big_drop,
    }
