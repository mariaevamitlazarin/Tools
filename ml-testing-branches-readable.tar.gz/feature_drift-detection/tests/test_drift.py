import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from mlpipe.data import make_dataset
from mlpipe.drift import population_stability_index, feature_drift


def test_psi_zero_for_same_dist():
    X, _, _ = make_dataset(n=2000, seed=1)
    psi = population_stability_index(X[:1000, 0], X[1000:, 0])
    assert psi < 0.1


def test_psi_detects_shift():
    ref, _, _ = make_dataset(n=2000, seed=1, drift=0.0)
    cur, _, _ = make_dataset(n=2000, seed=1, drift=2.0)
    psi = population_stability_index(ref[:, 0], cur[:, 0])
    assert psi > 0.2, f"expected drift, got PSI={psi}"


def test_feature_drift_flags_all_features():
    ref, _, _ = make_dataset(n=2000, seed=2, drift=0.0)
    cur, _, _ = make_dataset(n=2000, seed=2, drift=3.0)
    drifts = feature_drift(ref, cur)
    assert all(v > 0.2 for v in drifts.values())


@pytest.mark.evidently
def test_evidently_report_runs():
    pytest.importorskip("evidently")
    from mlpipe.drift import evidently_report
    ref, ry, _ = make_dataset(n=500, seed=1, drift=0.0)
    cur, cy, _ = make_dataset(n=500, seed=1, drift=2.0)
    out = evidently_report(ref, cur, ry, cy)
    assert isinstance(out, dict)
