"""Data drift & model drift detection for production (Evidently AI).

Includes a lightweight fallback drift metric (PSI) so tests have signal even
without Evidently installed.
"""
from __future__ import annotations
import numpy as np
from mlpipe.data import FEATURE_NAMES


def population_stability_index(ref: np.ndarray, cur: np.ndarray, bins: int = 10) -> float:
    """PSI between reference and current 1D distributions. >0.2 ~ significant drift."""
    quantiles = np.quantile(ref, np.linspace(0, 1, bins + 1))
    quantiles[0], quantiles[-1] = -np.inf, np.inf
    ref_pct = np.histogram(ref, quantiles)[0] / len(ref)
    cur_pct = np.histogram(cur, quantiles)[0] / len(cur)
    eps = 1e-6
    ref_pct = np.clip(ref_pct, eps, None)
    cur_pct = np.clip(cur_pct, eps, None)
    return float(np.sum((cur_pct - ref_pct) * np.log(cur_pct / ref_pct)))


def feature_drift(ref: np.ndarray, cur: np.ndarray) -> dict[str, float]:
    return {name: population_stability_index(ref[:, i], cur[:, i])
            for i, name in enumerate(FEATURE_NAMES)}


def evidently_report(ref_X, cur_X, ref_y=None, cur_y=None):
    """Build an Evidently data-drift report and return it as a dict.

    Evidently imported lazily. Works with the current `Report`/`DataDriftPreset` API.
    """
    import pandas as pd
    from evidently import Report
    from evidently.presets import DataDriftPreset

    ref = pd.DataFrame(np.asarray(ref_X), columns=FEATURE_NAMES)
    cur = pd.DataFrame(np.asarray(cur_X), columns=FEATURE_NAMES)
    if ref_y is not None:
        ref["target"] = ref_y
        cur["target"] = cur_y
    report = Report(metrics=[DataDriftPreset()])
    snapshot = report.run(reference_data=ref, current_data=cur)
    return snapshot.dict()
