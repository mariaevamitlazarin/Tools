"""Unit test suite for pipeline components (pytest)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pytest
from mlpipe.data import make_dataset, FEATURE_NAMES
from mlpipe.model import TorchClassifier

torch = pytest.importorskip("torch")


@pytest.fixture
def data():
    return make_dataset(n=500, seed=42)


def test_data_shapes(data):
    X, y, s = data
    assert X.shape == (500, len(FEATURE_NAMES))
    assert y.shape == (500,)
    assert set(np.unique(y)).issubset({0, 1})


def test_data_is_deterministic():
    X1, y1, _ = make_dataset(n=100, seed=7)
    X2, y2, _ = make_dataset(n=100, seed=7)
    assert np.allclose(X1, X2) and np.array_equal(y1, y2)


def test_drift_shifts_mean():
    X0, *_ = make_dataset(n=1000, seed=1, drift=0.0)
    X1, *_ = make_dataset(n=1000, seed=1, drift=2.0)
    assert X1.mean() > X0.mean() + 1.0


def test_model_fit_predict(data):
    X, y, _ = data
    clf = TorchClassifier(epochs=20).fit(X, y)
    preds = clf.predict(X)
    assert preds.shape == (500,)
    assert set(np.unique(preds)).issubset({0, 1})


def test_predict_proba_sums_to_one(data):
    X, y, _ = data
    clf = TorchClassifier(epochs=10).fit(X, y)
    p = clf.predict_proba(X)
    assert np.allclose(p.sum(axis=1), 1.0, atol=1e-5)


def test_model_learns_better_than_chance(data):
    X, y, _ = data
    acc = TorchClassifier(epochs=60).fit(X, y).score(X, y)
    assert acc > 0.6, f"train accuracy too low: {acc}"


@pytest.mark.parametrize("hidden", [4, 16, 32])
def test_various_widths(data, hidden):
    X, y, _ = data
    clf = TorchClassifier(hidden=hidden, epochs=15).fit(X, y)
    assert clf.predict(X).shape == (500,)
